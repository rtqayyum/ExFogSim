//
// Generated file, do not edit! Created by nedtool 4.6 from inet/applications/mqttapp/fognetMessages/MsgUpdateBrokers.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "MsgUpdateBrokers_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}



namespace inet {

// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(MsgUpdateBrokers);

MsgUpdateBrokers::MsgUpdateBrokers(const char *name, int kind) : ::cPacket(name,kind)
{
    this->FogLocationID_var = 0;
    this->FogID_var = 0;
    this->fogPrice_var = 0;
    this->fogAvailability_var = 0;
    this->fogComCost_var = 0;
    this->fogPort_var = 0;
    this->MIPS_var = 0;
}

MsgUpdateBrokers::MsgUpdateBrokers(const MsgUpdateBrokers& other) : ::cPacket(other)
{
    copy(other);
}

MsgUpdateBrokers::~MsgUpdateBrokers()
{
}

MsgUpdateBrokers& MsgUpdateBrokers::operator=(const MsgUpdateBrokers& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void MsgUpdateBrokers::copy(const MsgUpdateBrokers& other)
{
    this->FogLocationID_var = other.FogLocationID_var;
    this->FogID_var = other.FogID_var;
    this->fogPrice_var = other.fogPrice_var;
    this->fogAvailability_var = other.fogAvailability_var;
    this->fogComCost_var = other.fogComCost_var;
    this->fogPort_var = other.fogPort_var;
    this->MIPS_var = other.MIPS_var;
}

void MsgUpdateBrokers::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->FogLocationID_var);
    doPacking(b,this->FogID_var);
    doPacking(b,this->fogPrice_var);
    doPacking(b,this->fogAvailability_var);
    doPacking(b,this->fogComCost_var);
    doPacking(b,this->fogPort_var);
    doPacking(b,this->MIPS_var);
}

void MsgUpdateBrokers::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->FogLocationID_var);
    doUnpacking(b,this->FogID_var);
    doUnpacking(b,this->fogPrice_var);
    doUnpacking(b,this->fogAvailability_var);
    doUnpacking(b,this->fogComCost_var);
    doUnpacking(b,this->fogPort_var);
    doUnpacking(b,this->MIPS_var);
}

int MsgUpdateBrokers::getFogLocationID() const
{
    return FogLocationID_var;
}

void MsgUpdateBrokers::setFogLocationID(int FogLocationID)
{
    this->FogLocationID_var = FogLocationID;
}

const char * MsgUpdateBrokers::getFogID() const
{
    return FogID_var.c_str();
}

void MsgUpdateBrokers::setFogID(const char * FogID)
{
    this->FogID_var = FogID;
}

double MsgUpdateBrokers::getFogPrice() const
{
    return fogPrice_var;
}

void MsgUpdateBrokers::setFogPrice(double fogPrice)
{
    this->fogPrice_var = fogPrice;
}

double MsgUpdateBrokers::getFogAvailability() const
{
    return fogAvailability_var;
}

void MsgUpdateBrokers::setFogAvailability(double fogAvailability)
{
    this->fogAvailability_var = fogAvailability;
}

double MsgUpdateBrokers::getFogComCost() const
{
    return fogComCost_var;
}

void MsgUpdateBrokers::setFogComCost(double fogComCost)
{
    this->fogComCost_var = fogComCost;
}

int MsgUpdateBrokers::getFogPort() const
{
    return fogPort_var;
}

void MsgUpdateBrokers::setFogPort(int fogPort)
{
    this->fogPort_var = fogPort;
}

int MsgUpdateBrokers::getMIPS() const
{
    return MIPS_var;
}

void MsgUpdateBrokers::setMIPS(int MIPS)
{
    this->MIPS_var = MIPS;
}

class MsgUpdateBrokersDescriptor : public cClassDescriptor
{
  public:
    MsgUpdateBrokersDescriptor();
    virtual ~MsgUpdateBrokersDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(MsgUpdateBrokersDescriptor);

MsgUpdateBrokersDescriptor::MsgUpdateBrokersDescriptor() : cClassDescriptor("inet::MsgUpdateBrokers", "cPacket")
{
}

MsgUpdateBrokersDescriptor::~MsgUpdateBrokersDescriptor()
{
}

bool MsgUpdateBrokersDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<MsgUpdateBrokers *>(obj)!=NULL;
}

const char *MsgUpdateBrokersDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int MsgUpdateBrokersDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 7+basedesc->getFieldCount(object) : 7;
}

unsigned int MsgUpdateBrokersDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<7) ? fieldTypeFlags[field] : 0;
}

const char *MsgUpdateBrokersDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "FogLocationID",
        "FogID",
        "fogPrice",
        "fogAvailability",
        "fogComCost",
        "fogPort",
        "MIPS",
    };
    return (field>=0 && field<7) ? fieldNames[field] : NULL;
}

int MsgUpdateBrokersDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='F' && strcmp(fieldName, "FogLocationID")==0) return base+0;
    if (fieldName[0]=='F' && strcmp(fieldName, "FogID")==0) return base+1;
    if (fieldName[0]=='f' && strcmp(fieldName, "fogPrice")==0) return base+2;
    if (fieldName[0]=='f' && strcmp(fieldName, "fogAvailability")==0) return base+3;
    if (fieldName[0]=='f' && strcmp(fieldName, "fogComCost")==0) return base+4;
    if (fieldName[0]=='f' && strcmp(fieldName, "fogPort")==0) return base+5;
    if (fieldName[0]=='M' && strcmp(fieldName, "MIPS")==0) return base+6;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *MsgUpdateBrokersDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "string",
        "double",
        "double",
        "double",
        "int",
        "int",
    };
    return (field>=0 && field<7) ? fieldTypeStrings[field] : NULL;
}

const char *MsgUpdateBrokersDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int MsgUpdateBrokersDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    MsgUpdateBrokers *pp = (MsgUpdateBrokers *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string MsgUpdateBrokersDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    MsgUpdateBrokers *pp = (MsgUpdateBrokers *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getFogLocationID());
        case 1: return oppstring2string(pp->getFogID());
        case 2: return double2string(pp->getFogPrice());
        case 3: return double2string(pp->getFogAvailability());
        case 4: return double2string(pp->getFogComCost());
        case 5: return long2string(pp->getFogPort());
        case 6: return long2string(pp->getMIPS());
        default: return "";
    }
}

bool MsgUpdateBrokersDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    MsgUpdateBrokers *pp = (MsgUpdateBrokers *)object; (void)pp;
    switch (field) {
        case 0: pp->setFogLocationID(string2long(value)); return true;
        case 1: pp->setFogID((value)); return true;
        case 2: pp->setFogPrice(string2double(value)); return true;
        case 3: pp->setFogAvailability(string2double(value)); return true;
        case 4: pp->setFogComCost(string2double(value)); return true;
        case 5: pp->setFogPort(string2long(value)); return true;
        case 6: pp->setMIPS(string2long(value)); return true;
        default: return false;
    }
}

const char *MsgUpdateBrokersDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *MsgUpdateBrokersDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    MsgUpdateBrokers *pp = (MsgUpdateBrokers *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

} // namespace inet

